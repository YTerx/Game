using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[AddComponentMenu ("My components/TriggerEndLvl")]
public class TriggerEndLvl : MonoBehaviour
{
    [Header ("������ �����")]
    public int sceneIndex;

    void OnTriggerEnter (Collider myCollider)
    {
        if (myCollider.tag == ("Finish"))
        {
            SceneManager.LoadScene(sceneIndex);
        }
    }
}
