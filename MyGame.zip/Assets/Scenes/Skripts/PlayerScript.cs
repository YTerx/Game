using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        float move = Input.GetAxis("Vertical"); // ������ W � S
        float rotate = Input.GetAxis("Horizontal"); // ������ A � D
        transform.Translate(Vector3.right * move * 4f * Time.deltaTime); // �������� ���������

        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + move * 1f * Time.deltaTime);

        transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y + rotate * 130f * Time.deltaTime, transform.eulerAngles.z);
    }
}
